<?php
if($_SERVER["REQUEST_METHOD"]==="POST" && isset($_POST["sendGood"])){
    $email = $_POST["email"];
    $message = $_POST["message"];
}
?>